declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
